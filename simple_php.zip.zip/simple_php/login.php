<?php
$conn=mysqli_connect("localhost","root","","login");
if($conn){
    echo"SUCCESSFULLY <br>";
}
else {
    echo"failed";
}
$username=$_POST['username'];
$password=$_POST['password'];

$data = "INSERT INTO user VALUES('','$username','$password')";
$check = mysqli_query($conn,$data);
if($check){
    echo "data sended";
}
else{
   echo"not sent";
}
?>